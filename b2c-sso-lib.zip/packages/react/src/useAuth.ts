import { useEffect, useState } from 'react';
import { getToken, login, logout } from '@b2c/core';

export function useAuth(scopes: string[]) {
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    getToken(scopes)
      .then((res) => setToken(res.accessToken))
      .catch(() => login(window.location.href));
  }, []);

  return {
    token,
    logout
  };
}

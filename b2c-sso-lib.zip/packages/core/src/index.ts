import { PublicClientApplication, Configuration } from '@azure/msal-browser';

let msalInstance: PublicClientApplication;

export function init(config: Configuration) {
  msalInstance = new PublicClientApplication(config);
}

export function login(redirectUri: string) {
  return msalInstance.loginRedirect({ redirectUri });
}

export function logout() {
  return msalInstance.logout();
}

export function getToken(scopes: string[]) {
  return msalInstance.acquireTokenSilent({ scopes });
}

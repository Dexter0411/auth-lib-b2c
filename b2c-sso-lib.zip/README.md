# b2c-sso-lib

A modern Azure AD B2C authentication library built with React and extendable to Angular/Vanilla JS.

## Features

- Login, logout, and token management
- React hook support (`useAuth`)
- Simple and fast builds via esbuild
- Extendable for Angular or Vanilla JS

## Install

```bash
npm install b2c-sso-lib
```

## Usage (React)

```tsx
import { useAuth } from 'b2c-sso-lib';

const App = () => {
  const { token, logout } = useAuth(['openid', 'profile']);

  return <button onClick={logout}>Logout</button>;
};
```

## Build

```bash
npm run build
```

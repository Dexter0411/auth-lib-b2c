const esbuild = require('esbuild');
const path = require('path');

const shared = {
  bundle: true,
  sourcemap: true,
  minify: true,
  target: 'esnext',
  external: ['react', '@azure/msal-browser'],
};

Promise.all([
  esbuild.build({
    ...shared,
    entryPoints: ['packages/core/src/index.ts'],
    outfile: 'dist/core/index.js',
    format: 'esm',
  }),
  esbuild.build({
    ...shared,
    entryPoints: ['packages/react/src/index.ts'],
    outfile: 'dist/react/index.js',
    format: 'esm',
  })
]).then(() => console.log('✅ Build complete'));
